// deven-script.js

// --- 1. LOGIKA GENERATOR PARTIKEL ---
function createParticles() {
    const container = document.getElementById('particles-container');
    const particleCount = 50; // Jumlah partikel

    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');

        // Ukuran acak (2px - 6px)
        const size = Math.random() * 4 + 2;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;

        // Posisi horizontal acak (0% - 100%)
        particle.style.left = `${Math.random() * 100}%`;
        
        // Posisi vertikal acak (biar pas awal load kesebar)
        particle.style.top = `${Math.random() * 100}%`;

        // Durasi animasi acak (10s - 20s) biar kecepatannya beda-beda
        particle.style.animationDuration = `${Math.random() * 10 + 10}s`;
        
        // Delay animasi acak biar nggak barengan munculnya
        particle.style.animationDelay = `${Math.random() * 5}s`;

        container.appendChild(particle);
    }
}

// Jalankan generator partikel saat halaman dimuat
window.addEventListener('load', createParticles);


// --- 2. LOGIKA TABS PORTFOLIO (Sama kayak sebelumnya, tpi make sure clean) ---
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Hapus active class
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Tambah active class ke yang diklik
        button.classList.add('active');
        const tabId = button.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
    });
});
